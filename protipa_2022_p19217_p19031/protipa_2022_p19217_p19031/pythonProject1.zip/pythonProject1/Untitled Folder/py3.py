import tensorflow as tf

from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam
from keras.callbacks import EarlyStopping

import pandas as pd
import numpy as np
import padasip as pad
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
import sklearn
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score

from matplotlib import pyplot as plt
def normalizedata(dt):
    return (dt - np.min(dt)) / (np.max(dt) - np.min(dt))


plt.rcParams["figure.figsize"] = [7.00, 3.50]
plt.rcParams["figure.autolayout"] = True
columns = ["longitude", "latitude", "housing_median_age", "total_rooms"
    , "total_bedrooms", "population", "households", "median_income",
           "median_house_value", "ocean_proximity"]
data = pd.read_csv("housing.csv", usecols=columns)
data.fillna(data.total_bedrooms.mean(),inplace=True)
scaled_long = normalizedata(data.longitude)
plt.show()
scaled_lat = normalizedata(data.latitude)
scaled_age = normalizedata(data.housing_median_age)
scaled_room = normalizedata(data.total_rooms)
scaled_bed = normalizedata(data.total_bedrooms)
scaled_pop = normalizedata(data.population)
scaled_houses = normalizedata(data.households)
scaled_income = normalizedata(data.median_income)
scaled_value = normalizedata(data.median_house_value)

label_encoder = LabelEncoder()
integer_encoded = label_encoder.fit_transform(data.ocean_proximity)
# print(integer_encoded)
onehot_encoder = OneHotEncoder(sparse=False)
integer_encoded = integer_encoded.reshape(len(integer_encoded), 1)
onehot_encoded_ocean = onehot_encoder.fit_transform(integer_encoded)
# print(onehot_encoded_ocean)

scaled_ocean = normalizedata(onehot_encoded_ocean)
# print(scaled_ocean)
'''plt.scatter(scaled_long, scaled_lat)
plt.show()

plt.scatter(scaled_value,scaled_income)
plt.show()'''

plt.hist(data.longitude, bins=16, density=True, stacked=True)
# plt.legend()
plt.title('Histogram 1')
plt.xlabel('Longitude')
plt.ylabel('Prob dencity')
plt.show()

plt.hist(data.latitude, bins=16, density=True, stacked=True)
plt.title('Histogram 2')
plt.xlabel('latitude')
plt.ylabel('Prob dencity')
plt.show()

plt.hist(data.housing_median_age, bins=16, density=True, stacked=True)
plt.title('Histogram 3')
plt.xlabel('age')
plt.ylabel('Prob dencity')
plt.show()

plt.hist(data.total_rooms, bins=64, density=True, stacked=True)
plt.title('Histogram 4')
plt.xlabel('rooms')
plt.ylabel('Prob dencity')
plt.show()

plt.hist(data.total_bedrooms, bins=64, density=True, stacked=True)
plt.title('Histogram 5')
plt.xlabel('beds')
plt.ylabel('Prob dencity')
plt.show()

plt.hist(data.population, bins=64, density=True, stacked=True)
plt.title('Histogram 6')
plt.xlabel('population')
plt.ylabel('Prob dencity')
plt.show()

plt.hist(data.households, bins=64, density=True, stacked=True)
plt.title('Histogram 7')
plt.xlabel('houses')
plt.ylabel('Prob dencity')
plt.show()

plt.hist(data.median_income, bins=16, density=True, stacked=True)
plt.title('Histogram 8')
plt.xlabel('income')
plt.ylabel('Prob dencity')
plt.show()

plt.hist(data.ocean_proximity, bins=16, density=True, stacked=True)
plt.title('Histogram 9')
plt.xlabel('ocean')
plt.ylabel('Prob dencity')
plt.show()

'''
print(data.ocean_proximity)
print(data.median_house_value)
print(data.median_income)
print(data.households)
print(data.population)
print(data.total_bedrooms)
print(data.total_rooms)
print(data.housing_median_age)
print(data.latitude)
print(data.longitude)
'''

Y_true = np.c_[
    scaled_long, scaled_lat, scaled_bed, scaled_age, scaled_room, scaled_income, scaled_pop, scaled_houses, scaled_ocean]
# print(Y_true)
Y_pred = np.c_[scaled_value]
# print(Y_pred)
MSE = np.square(np.subtract(Y_true.transpose(), Y_pred.transpose())).mean()
print(MSE)

X_train, X_test, y_train, y_test = train_test_split(Y_pred, Y_true, test_size=0.2)
# Plots the results of a learning rate of 100, 1000, and 10000 respectively, with all other parameters constant

X_train = preprocessing.scale(X_train)

X_test = preprocessing.scale(X_test)

LR = [100, 1000, 10000]

for i in LR:
    # Defines linear regression model and its structure
    model = Sequential()
    model.add(Dense(1, input_shape=(3,)))

    # Compiles model
    model.compile(Adam(learing_rate=i), 'mean_squared_error')

    # Fits model
    history = model.fit(X_train, y_train, epochs=500, validation_split=0.1, verbose=0)
    history_dict = history.history

    # Plots model's training cost/loss and model's validation split cost/loss
    loss_values = history_dict['loss']
    val_loss_values = history_dict['val_loss']
    plt.figure()
    plt.plot(loss_values, 'bo', label='training loss')
    plt.plot(val_loss_values, 'r', label='val training loss')

# Runs and plots the performance of a model with the same parameters from before (and a learning rate of 10000),
# but now with an activation function (Relu)

model = Sequential()
model.add(Dense(1, input_shape=(3,), activation = 'relu'))
model.compile(Adam(lr=10000), 'mean_squared_error')
history = model.fit(X_train, y_train, epochs = 500, validation_split = 0.1,verbose = 0)

history_dict=history.history
loss_values = history_dict['loss']
val_loss_values=history_dict['val_loss']
plt.plot(loss_values,'bo',label='training loss')
plt.plot(val_loss_values,'r',label='training loss val')

#Runs model (the one with the activation function, although this doesn't really matter as they perform the same)
# with its current weights on the training and testing data
y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)

# Calculates and prints r2 score of training and testing data
print("The R2 score on the Train set is:\t{:0.3f}".format(r2_score(y_train, y_train_pred)))
print("The R2 score on the Test set is:\t{:0.3f}".format(r2_score(y_test, y_test_pred)))
